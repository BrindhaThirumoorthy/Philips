# Get the current directory where the script is located
$SCRIPT_DIR = Split-Path -Parent $MyInvocation.MyCommand.Path

# Prompt the user for a suffix (optional)
$suffix = Read-Host "Enter suffix for the service name (leave empty for default)"

# Build service names based on suffix
if ($suffix -ne "") {
    $serviceName = "symops_$suffix"
    $updaterServiceName = "symops_updater_$suffix"
} else {
    $serviceName = "symops"
    $updaterServiceName = "symops_updater"
}

# Check if script is running with admin privileges
if (-NOT ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Write-Error "This script requires administrative privileges. Please run PowerShell as Administrator."
    Write-Host "Press Enter to exit..."
    Read-Host
    exit 1
}

try {
    # Check and remove the main service
    $service = Get-Service -Name $serviceName -ErrorAction SilentlyContinue
    if ($service) {
        Write-Host "Stopping $serviceName service..." -ForegroundColor Yellow
        Stop-Service -Name $serviceName -Force -ErrorAction SilentlyContinue

        Write-Host "Removing $serviceName service..." -ForegroundColor Yellow
        sc.exe delete $serviceName | Out-Null

        # Verify removal
        if (-not (Get-Service -Name $serviceName -ErrorAction SilentlyContinue)) {
            Write-Host "$serviceName service removed successfully." -ForegroundColor Green
        } else {
            Write-Host "Failed to remove $serviceName service." -ForegroundColor Red
        }
    } else {
        Write-Host "Service '$serviceName' does not exist. Nothing to remove." -ForegroundColor Yellow
    }

    # Check and remove the updater service
    $updaterService = Get-Service -Name $updaterServiceName -ErrorAction SilentlyContinue
    if ($updaterService) {
        Write-Host "Stopping $updaterServiceName service..." -ForegroundColor Yellow
        Stop-Service -Name $updaterServiceName -Force -ErrorAction SilentlyContinue

        Write-Host "Removing $updaterServiceName service..." -ForegroundColor Yellow
        sc.exe delete $updaterServiceName | Out-Null

        # Verify removal
        if (-not (Get-Service -Name $updaterServiceName -ErrorAction SilentlyContinue)) {
            Write-Host "$updaterServiceName service removed successfully." -ForegroundColor Green
        } else {
            Write-Host "Failed to remove $updaterServiceName service." -ForegroundColor Red
        }
    } else {
        Write-Host "Service '$updaterServiceName' does not exist. Nothing to remove." -ForegroundColor Yellow
    }

    Write-Host "Cleanup operation completed successfully." -ForegroundColor Green
} catch {
    Write-Error "Error during cleanup: $_"
}

Write-Host "Press Enter to exit..."
Read-Host
