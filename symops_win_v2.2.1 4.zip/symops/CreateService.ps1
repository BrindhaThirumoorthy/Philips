# Get the current directory where the script is located
$SCRIPT_DIR = Split-Path -Parent $MyInvocation.MyCommand.Path

# Prompt the user for a suffix (optional)
$suffix = Read-Host "Enter suffix for the service name (leave empty for default)"

# Build service names based on suffix
if ($suffix -ne "") {
    $serviceName = "symops_$suffix"
    $updaterServiceName = "symops_updater_$suffix"
} else {
    $serviceName = "symops"
    $updaterServiceName = "symops_updater"
}

# Check if script is running with admin privileges
if (-NOT ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Write-Error "This script requires administrative privileges. Please run PowerShell as Administrator."
    Write-Host "Press Enter to exit..."
    Read-Host
    exit 1
}

try {
    # Check if services already exist
    $symopsNewExists = Get-Service -Name $serviceName -ErrorAction SilentlyContinue
    $symopsUpdaterExists = Get-Service -Name $updaterServiceName -ErrorAction SilentlyContinue
    
    # Handle symops service
    $servicePath = Join-Path -Path $SCRIPT_DIR -ChildPath "bin\WinSW.NET4.exe"
    if (-not (Test-Path $servicePath)) {
        throw "Service executable not found at: $servicePath"
    }
    
    if ($symopsNewExists) {
        Write-Host "Service '$serviceName' already exists. Skipping creation." -ForegroundColor Yellow
    } else {
        New-Service -Name $serviceName -BinaryPathName $servicePath -StartupType Automatic -ErrorAction Stop
        Write-Host "$serviceName service created successfully." -ForegroundColor Green
    }
    
    # Handle symops_updater service
    $updaterPath = Join-Path -Path $SCRIPT_DIR -ChildPath "bin\WinSW.NET4_updater.exe"
    if (-not (Test-Path $updaterPath)) {
        throw "Updater executable not found at: $updaterPath"
    }
    
    if ($symopsUpdaterExists) {
        Write-Host "Service '$updaterServiceName' already exists. Skipping creation." -ForegroundColor Yellow
    } else {
        New-Service -Name $updaterServiceName -BinaryPathName $updaterPath -StartupType Automatic -ErrorAction Stop
        Write-Host "$updaterServiceName service created successfully." -ForegroundColor Green
    }
    
    Write-Host "Operation completed successfully."
} catch {
    Write-Error "Error creating services: $_"
}

Write-Host "Press Enter to exit..."
Read-Host
