# Powershell script
# in_list.ps1  with jq command
# written by apr
# Created on 13/01/2025
# Modified on 14/02/2025
# Modified on 20/07/2025 allow issue
# Exit on error
Set-StrictMode -Version Latest

# Force TLS 1.2 and ignore SSL validation
Add-Type @"
using System.Net;
using System.Security.Cryptography.X509Certificates;
public class TrustAllCertsPolicy : ICertificatePolicy {
    public bool CheckValidationResult(ServicePoint srvPoint, X509Certificate certificate, WebRequest request, int certificateProblem) {
        return true;
    }
}
"@
[System.Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType]::Tls12
[System.Net.ServicePointManager]::CertificatePolicy = New-Object TrustAllCertsPolicy

# Function to escape special characters in strings for JSON
function json_escape {
    param(
        [string]$inputString
    )
    $inputString -replace '["\\/]', '\\$&' -replace "`r`n", "`n"
}

# Assign input arguments to variables
$PARAM_NAME = $args[0]
$CURRENT_VALUE = $args[1]
$COMPARISON_VALUE = $args[2]
$COMPARISON_TYPE = $args[3]
$POLICY_NAME = $args[4]
$HOSTNAME = $args[5]
$PORT = $args[6]

# Escape current and comparison values for JSON
$CURRENT_VALUE_ESCAPED = (json_escape $CURRENT_VALUE)
$PARAM_NAME_ESCAPED = (json_escape $PARAM_NAME)

# If comparison value is a JSON array in string form, convert to array first
if ($COMPARISON_VALUE -is [string] -and $COMPARISON_VALUE.Trim().StartsWith('[')) {
    $COMPARISON_VALUE = $COMPARISON_VALUE | ConvertFrom-Json | ConvertTo-Json -Compress
}

# Get the path of the currently executing script
$Source = $MyInvocation.MyCommand.Definition

# Resolve symbolic links (if applicable)
while ([System.IO.File]::GetAttributes($Source) -band [System.IO.FileAttributes]::ReparsePoint) {
    $Dir = (Get-Item $Source).Directory.FullName
    $Source = Resolve-Path $Source
}

# Get the directory of the script
$ScriptDir = (Get-Item $Source).Directory.FullName

# Assume SCRIPT_DIR is /opt/rise/harmony/bin or /opt/rise/harmony/evaluators
# Find the base directory (equivalent to ../../../../)
$BaseDir = Resolve-Path (Join-Path -Path $ScriptDir -ChildPath "..\..")
# Construct the decision path relative to the base directory
$DecisionDir = Join-Path -Path $BaseDir -ChildPath "harmony\decisions"

# Verify that the decision path exists
if (-Not (Test-Path -Path $DecisionDir -PathType Container)) {
    Write-Host "Error: Decisions directory not found at $DecisionDir" 
    exit 1
}



# Construct the decision path

$decision_path = "$DecisionDir/$COMPARISON_TYPE.rego" -replace '\\', '/'

# Write-Host "Decision Path: $decision_path"

# Construct JSON payload manually
$PAYLOAD = @"
{
  "rulepath": "$decision_path",
  "ruleinput": {
    "current_value": "$CURRENT_VALUE_ESCAPED",
    "comparison_value": $COMPARISON_VALUE,
    "param_name": "$PARAM_NAME_ESCAPED"
  },
  "ruleeval": "data.$COMPARISON_TYPE.result"
}
"@ | jq -c .

# Debug: Show Payload
# Write-Host "DEBUG: Payload being sent: $PAYLOAD"

#
# Fix: Ensure JSON is properly escaped for Windows PowerShell
$PAYLOAD = $PAYLOAD -replace '"', '\"'
# Write-Host "New Payload in in_list : $PAYLOAD"


# Execute curl directly
$RESPONSE = & curl.exe -s -k --http1.1 --location "https://${HOSTNAME}:${PORT}/agent/decision-engine/execute" `
    --header "Content-Type: application/json" `
    --data "`"$PAYLOAD`""

# Debug: Show Response
# Write-Host "Raw API Response in in_list: $RESPONSE"

# Validate JSON format using jq (handle errors)
if (-not ($RESPONSE | jq '.' 2>$null)) {
    Write-Host "ERROR: Invalid JSON response from decision engine"
    Write-Host "Full Response: $RESPONSE"
    exit 1
}

# Extract 'allow' and 'success' fields safely
$ALLOW = $RESPONSE | jq -r '.output.allow' 2>$null
$SUCCESS = $RESPONSE | jq -r '.success' 2>$null

if (-not $ALLOW -or -not $SUCCESS) {
    Write-Host "ERROR: Missing 'allow' or 'success' fields in API response."
    Write-Host "Full Response: $RESPONSE"
    exit 1
}

# Construct final result JSON manually
$RESULT = @"
{
  "allow": $ALLOW,
  "success": $SUCCESS
}
"@

# Output the final result
# Write-Host "Final result in in_list "
Write-Output $RESULT

