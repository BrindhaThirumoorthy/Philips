
# PowerShell Discovery Script 
# modified on 23/06/2025 to create json format 

# Output file path
$outputFile = "C:\tmp\config_details.txt"

# Create output directory if it doesn't exist
if (!(Test-Path "C:\tmp")) {
    New-Item -Path "C:\tmp" -ItemType Directory 2>&1
}

# Remove the file if it exists to ensure it is overwritten
if (Test-Path $outputFile) {
    Remove-Item $outputFile -Force
}

# Global Metadata Object
$global:Metadata = @{
    Platform       = "Unknown"
    VMName         = ""
    Region         = ""
    SubscriptionId = ""
    OSName         = ""
    OSVersion      = ""
    Hostname       = $env:COMPUTERNAME
    CPUCores       = 0
    MemoryGB       = 0
    DiskTotalGB    = 0
    dbvendorname   = ""
    dbrelease      = ""
}

#=================================================================================
# Collect OS and Hardware Details
# Get OS details
#==================================================================================
# Get the current hostname
$hostname = $env:COMPUTERNAME

$os = Get-WmiObject -Class Win32_OperatingSystem
Write-Output "osPlatform: $($os.Caption)" >> $outputFile
Write-Output "osArchitecture: $($os.OSArchitecture)" >> $outputFile
Write-Output "osVersion: $($os.Version)" >> $outputFile
# Write-Output "vmHostname: $($env:COMPUTERNAME)" >> $outputFile

# Get CPU and Memory details
$cpuCores = (Get-WmiObject -Class Win32_Processor | Measure-Object -Property NumberOfCores -Sum).Sum
$memory = [math]::Round((Get-WmiObject -Class Win32_ComputerSystem).TotalPhysicalMemory / 1GB, 2)

# Get Swap space (Page File Usage)
$swapUsage = Get-WmiObject -Class Win32_PageFileUsage
$swapTotal = ($swapUsage | Measure-Object -Property AllocatedBaseSize -Sum).Sum
$swap = if ($swapTotal -ne $null) { [math]::Round($swapTotal / 1024, 2) } else { 0 }

$disk = Get-CimInstance Win32_LogicalDisk -Filter "DriveType=3" | Measure-Object Size -Sum
$DiskTotalGB = [math]::Round($disk.Sum / 1GB, 2)

Write-Output "cpuCores:  $cpuCores" >> $outputFile
Write-Output "ramMemory: ${memory}GB" >> $outputFile
Write-Output "swapSpace: ${swap}GB" >> $outputFile
Write-Output "diskStorageGb: $DiskTotalGB" >> $outputFile

# Get IP details
$ipAddresses = (Get-NetIPAddress -AddressFamily IPv4 | Where-Object { $_.IPAddress -ne "127.0.0.1" }).IPAddress
$numIPs = $ipAddresses.Count
if ($numIPs -gt 1) {
    $primaryIP = $ipAddresses[0]
    $secondaryIPs = $ipAddresses[1..($ipAddresses.Count - 1)] -join ", "
    Write-Output "secondaryIpAssigned: Yes" >> $outputFile
    Write-Output "primaryIp: $primaryIP" >> $outputFile
    Write-Output "secondaryIp: $secondaryIPs" >> $outputFile
} else {
    Write-Output "secondaryIpAssigned: No" >> $outputFile
    Write-Output "primaryIp: $ipAddresses" >> $outputFile
}



# Detect Cloud Platform
function Detect-Platform {
    try {
        $url = "http://169.254.169.254/metadata/instance?api-version=2021-02-01&format=json"
        $response = Invoke-RestMethod -Uri $url -Headers @{Metadata = "true"} -TimeoutSec 2 -ErrorAction Stop
        if ($response.compute) {
            $platform = "Azure"
            Get-AzureMetadata $response
            return
        }
    } catch {}

    try {
        $instanceId = Invoke-RestMethod -Uri "http://169.254.169.254/latest/meta-data/instance-id" -TimeoutSec 2 -ErrorAction Stop
    if ($instanceId) {
        $platform = "AWS"
        Get-AWSMetadata
        return
       }
    } catch {}


    try {
        $url = "http://169.254.169.254/computeMetadata/v1/"
        $response = Invoke-RestMethod -Uri $url -Headers @{ "Metadata-Flavor" = "Google" } -TimeoutSec 2 -ErrorAction Stop
        if ($response -match "instance/") {
            $platform = "GCP"
            Get-GcpMetadata
            return
        }
    } catch {}

    $platform = "Unknown"
}



# Azure Metadata
function Get-AzureMetadata($response) {
    # Write-Host "Executing Get-AzureMetadata function"
    $vmName = $response.compute.name
    $region = $response.compute.location
    $subscriptionId = $response.compute.subscriptionId

Write-Output "cloudPlatform: $platform" >> $outputFile
Write-Output "vmName: $vmName" >> $outputFile
Write-Output "vmRegion: $region" >> $outputFile
Write-Output "subScriptionId: $subscriptionId" >> $outputFile

}

# AWS Metadata
    function Get-AWSMetadata {
    try {
        # Get the IMDSv2 token
        $token = Invoke-RestMethod -Uri http://169.254.169.254/latest/api/token `
                                   -Method PUT `
                                   -Headers @{ 'X-aws-ec2-metadata-token-ttl-seconds' = '21600' }

        $headers = @{ 'X-aws-ec2-metadata-token' = $token }

        # Retrieve metadata values
        $instanceId = Invoke-RestMethod -Uri http://169.254.169.254/latest/meta-data/instance-id -Headers $headers
        $vmName = Invoke-RestMethod -Uri http://169.254.169.254/latest/meta-data/hostname -Headers $headers
        $identityDoc = Invoke-RestMethod -Uri http://169.254.169.254/latest/dynamic/instance-identity/document -Headers $headers
        $accountId = $identityDoc.accountId
        $region = $identityDoc.region

        
   Write-Output "cloudPlatform: $platform" >> $outputFile
   Write-Output "vmName: $vmName" >> $outputFile
   Write-Output "vmRegion: $region" >> $outputFile
   Write-Output "instanceId: $instanceId" >> $outputFile
   Write-Output "accountId: $accountId" >> $outputFile
        
    }
    catch {
        Write-Warning "Failed to fetch AWS metadata"
    }
}

function Get-GcpMetadata {
    $headers = @{ "Metadata-Flavor" = "Google" }
    $baseUrl = "http://169.254.169.254/computeMetadata/v1"
# echo "$platform"

    try {
        $zonePath = Invoke-RestMethod -Uri "$baseUrl/instance/zone" -Headers $headers -TimeoutSec 2
        $zone = $zonePath.Split("/")[-1]                   # Example: asia-south1-b
        $region = $zone -replace "-[a-z]$",""              # Remove zone suffix to get region

        $vmName    = Invoke-RestMethod -Uri "$baseUrl/instance/name" -Headers $headers -TimeoutSec 2
        $projectId = Invoke-RestMethod -Uri "$baseUrl/project/project-id" -Headers $headers -TimeoutSec 2
        $gcpzone   = $zone
        $gcpregion = $region

   Write-Output "cloudPlatform: $platform" >> $outputFile
   Write-Output "vmName: $vmName" >> $outputFile
   Write-Output "gcpZone: $gcpZone" >> $outputFile
   Write-Output "gcpRegion: $gcpRegion" >> $outputFile
   Write-Output "projectId: $projectId" >> $outputFile
  

    } catch {
        Write-Warning "Failed to retrieve GCP metadata: $_"
    }
}



function Collect-databaseInfo {
# Get SAP Hostagent version and patch information
$hostAgentPath = "C:\Program Files\SAP\hostctrl\exe\saphostctrl.exe"


#-----------------------------------------------------------
# Database Details
#-------------------------------------------------------------

# Define the saphostctrl command to retrieve database systems
# Define the full path to the saphostctrl command
if (Test-Path $hostAgentPath) {
$output = & "$hostAgentPath" -function ListDatabaseSystems | Select-String -Pattern "^Database name:"
# echo "$output"
foreach ($line in $output) {
    # Extract the database SID
    $dbsid = ($line -split "Database name:")[1] -split "," | Select-Object -First 1
    $dbSID = $dbsid.Trim()
    

    # Extract the vendor
    $dbvendor = ($line -split "Vendor:")[1] -split "," | Select-Object -First 1
    $dbvendor = $dbvendor.Trim()

    # Extract the type
    $dbtype = ($line -split "Type:")[1] -split "," | Select-Object -First 1
    $dbtype = $dbtype.Trim()

    # Extract the release
    $dbrelease = ($line -split "Release:")[1] -split "," | Select-Object -First 1
    $dbrelease = $dbrelease.Trim()



    # Assign the vendor name based on the value of $dbvendor
    switch ($dbvendor) {
        "ADA" { $dbvendorname = "MAXDB" }
        "MSS" { $dbvendorname = "MSSQL" }
        "SYB" { $dbvendorname = "Sybase" }
        "ORA" { $dbvendorname = "Oracle" }
        default { $dbvendorname = "Unknown" }
    }
# Check if all values were successfully extracted and display them
# if ($dbsid -and $dbvendor -and $dbtype -and $dbrelease ) {
#     Write-Output "dBSid: $dbsid" 
#     Write-Output "dBVendor: $dbvendor" 
#     Write-Output "dBVendorName: $dbvendorname" 
#     Write-Output "dBType: $dbtype" 
#     Write-Output "dBRelease: $dbrelease" 
#    Write-Output "dBHostName: $hostname" 


if ($dbSID -eq $SAPSID -or $SYSTEM_TYPE -eq "CS") {
    if ($dbtype) {
        Write-Output "${SAPSID}dbType: $dbtype" >> $outputFile
       }

    if ($dbvendorname) {
        Write-Output "${SAPSID}dbVendor: $dbvendorname" >> $outputFile
     }

    if ($dbrelease) {
        Write-Output "${SAPSID}dbRelease: $dbrelease" >> $outputFile
        }
    }
    
  }
 }
}    # end of function collect-dbinfo

#=========================================================================================
# function for Java information 
#==========================================================================================
function Collect-j2eeInfo {
     $script:SystemName = "SAP NetWeaver JAVA"
      $SYSTEM_TYPE = "JAVA"
     
# Write-Host "jinstance  $jinstance"
# Get all drives on the system (only filesystem drives)
$drives = Get-PSDrive -PSProvider FileSystem | Select-Object -ExpandProperty Root



# Loop through each available drive to find the file
foreach ($drive in $drives) {
    $filePath = "$base_path\$SAPSID\$jinstance\work\std_server0.out"
# Write-Host "$filePath"
# Write-Host "filePath is $filePath"   
    if (Test-Path $filePath) {
        # Retrieve NetWeaver version
        $nwVersion = Select-String -Path $filePath -Pattern 'AS Java version \[([0-9]+)\.([0-9]+)' | Select-Object -First 1 |ForEach-Object { $_.Matches.Groups[1].Value + "." + $_.Matches.Groups[2].Value }
# Write-Host "$nwVersion"        
        # Remove the dot from the version (e.g., 7.50 -> 750)
        $nwVersion = $nwVersion -replace '\.', ''

        # Retrieve NetWeaver SP level
        $nwSP = Select-String -Path $filePath -Pattern 'SP ([0-9]+)' | Select-Object -First 1 |ForEach-Object { $_.Matches.Groups[1].Value }

        break # Exit loop once the file is found
           }
       }

# Output results to file if version and SP level are found
 
$j2eeVersionsp="$nwVersion $nwSP" 
if ($j2eeVersionsp) { 
Write-Output "${SAPSID}j2eeVersion: $j2eeVersionsp" >> $outputFile
}
Write-Output "${SAPSID}systemName: $SystemName" >> $outputFile
# Write-Host "$SAPSID $SystemName $SYSTEM_TYPE $Versionsp  $jinstance $unicode_stat $environment"

 
} # end of function collect-j2eeInfo
#===============================================================================================

#=========================================================================================
# function for ABAP information 
#==========================================================================================
function Collect-ABAPInfo {
                   $SYSTEM_TYPE = "ABAP" 

		# Execute sapcontrol command to get the component list
		$output = & "${exe_path}\sapcontrol.exe" -nr $applinstance_number -prot PIPE -function ABAPGetComponentList
#  echo "exe path  and Instance number : $exe_path  $instance_number"
# Netweaver 
  #  Extract NetWeaver information for SAP_BASIS
		$netweaver_info = $output | Select-String -Pattern "SAP_BASIS"
  #   Check if there is information about SAP_APPL

	       $appl_info = $output | Select-String -Pattern "SAP_APPL"
# Check if there is information about Solution manager
               $sm_info = $output | Select-String -Pattern "ST,"

#Obtain NW version and SP
		if ($netweaver_info) {
   # Split the line by commas and store the results in an array
 		   $split_info = $netweaver_info -split ','

    # The second element in the array is the NetWeaver version (750)
		    $NWversion = $split_info[1].Trim()

    # The third element in the array is the SPS level (0)
   		 $sps_level = $split_info[2].Trim()
                    
$script:SystemName="SAP NetWeaver"
$script:applVersionsp="$NWversion $sps_level"

		}  elseif ($appl_info) {
#---------------------------------------------------------------------
# SAP ERP
#---------------------------------------------------------------------

    # Split the line by commas and store the results in an array
	    $split_appl_info = $appl_info -split ','

    # The second element is the application version, and the third is the SPS level
 	   $applversion = $split_appl_info[1].Trim()
 	   $sps_level = $split_appl_info[2].Trim()

$script:SystemName="SAP ERP"
  
$script:applVersionsp="$applversion $sps_level"
 
                 } elseif ($sm_info) {

#----------------------------------------------------------
# solution manager Version and SPS 
# Check if there is information about ST Component of Solution Manager
#-------------------------------------------------------------------

	
    # Split the line by commas and store the results in an array
	    $split_sm_info = $sm_info -split ','

    # The second element is the application version, and the third is the SPS level
 	   $smversion = $split_sm_info[1].Trim()
 	   $sm_sps_level = $split_sm_info[2].Trim()
    $script:SystemName="Solman Server"
    $script:applVersionsp="$smversion $sm_sps_level" 
    } 


# Write-Host ( "$SID $SystemName  $SYSTEM_TYPE $environment $unicode_stat $Versionsp  ")



}  # End of function collect-ABAPInfo

# MAIN



Write-Host "`nRunning system discovery..."

Detect-Platform
# Collect-databaseInfo 





#====================================================================================
# SAP Application
#=====================================================================================
$foundValidSID = $false
$drives = Get-PSDrive -PSProvider FileSystem | Where-Object { $_.Free -gt 0 -and $_.Root -match "^[A-Z]:\\$" }
$alreadyExists = $false
# 1. List the windows drives
foreach ($drive in $drives) {
    $base_path = Join-Path -Path $drive.Root -ChildPath "usr\sap"

# 2 test base_path is present or not in a specific  which drive 
    if (Test-Path $base_path) {
        $dirs = Get-ChildItem -Path $base_path -Directory
# 3 
        foreach ($dir in $dirs) {
            $SAPSID = $dir.Name
if ($SAPSID -eq "DAA") {
        continue  # Skip this SID and move to the next one
    }
            $profile_path = Join-Path -Path $base_path -ChildPath "$SAPSID\SYS\profile"
            $exe_path     = Join-Path -Path $base_path -ChildPath "$SAPSID\SYS\exe\uc\NTAMD64"

# 4 Obtain Valid SID
            if ((Test-Path $profile_path) -and (Test-Path $exe_path)) {
       $foundValidSID = $true   # Valid SAP system found
# Arrays and flags
           $dxx_instances = @()
           $jxx_instances = @()
                # Reset instance flags
                $has_ascs = $false
                $has_scs  = $false
                $has_d    = $false
                $has_dvebmgs  = $false
                $has_j    = $false
                $has_w    = $false
                $SystemName = ""
                $SYSTEM_TYPE = ""
                $ascsinstance_number = ""
                $scsinstance_number = ""
                $dvebmgsinstance_number = ""
                $applinstance_number = ""
                $j2eeinstance_number = ""
                $ersinstance_number = ""
                $wdinstance_number = ""
                $csinstance_number = ""

$environment = "Unknown"  # default
switch -Wildcard ($SAPSID) {
    "DEV"  { $environment = "Dev" }
    "*D"   { $environment = "Dev" }
    "QAS"  { $environment = "Qual" }
    "*Q"   { $environment = "Qual" }
    "PRD"  { $environment = "Prod" }
    "*P"   { $environment = "Prod" }
    "SBX"  { $environment = "Sandbox" }
    "*S"   { $environment = "Sandbox" }
    "TST"  { $environment = "Test" }
    "*T"   { $environment = "Test" }
    default { $environment = "Unknown" }
}

                # Get all profile files for the SID
                $profile_files = Get-ChildItem -Path $profile_path | Where-Object { $_.Name -match "$($SAPSID)_([A-Z]+)([0-9]+)_(.+)$" }


                foreach ($file in $profile_files) {
                    $filename = $file.Name
#  Write-Host "Checking file: $filename"

                   
                    if ($filename -match "^$($SAPSID)_(DVEBMGS)([0-9][0-9])_(.+)$") {
                        $has_dvebmgs = $true
                        $instance_name = $matches[1]
                        $instance_number = $matches[2]
                        $dvebmgsinstance_number = $instance_number
# Write-Host "dvebmgs_instance: $dvebmgsinstance_number"
                         $SYSTEM_TYPE = "ABAP"

                     } elseif ($filename -match "^$($SAPSID)_(D)([0-9][0-9])_(.+)$") {
                        $has_d = $true
                        $instance_name = $matches[1]
                        $instance_number = $matches[2]
                        $applinstance_number = $instance_number
                        $dxx_instances += $instance_number
                         $SYSTEM_TYPE = "ABAP"
# Write-Host "dxx_instances: $dxx_instances"

                    } elseif ($filename -match "^$($SAPSID)_(ASCS)([0-9][0-9])_(.+)$") {
                        $has_ascs = $true
                        $instance_name = $matches[1]
                        $instance_number = $matches[2]
                        $ascsinstance_number = $instance_number
                         $SYSTEM_TYPE = "ABAP"
                     
                    } elseif ($filename -match "^$($SAPSID)_(J)([0-9][0-9])_(.+)$") {
                        $has_j = $true
                        $instance_name = $matches[1]
                        $instance_number = $matches[2]
                        $j2eeinstance_number = $instance_number
                        $jinstance = "$instance_name$instance_number"
                        $jxx_instances += $instance_number
                        $SYSTEM_TYPE = "JAVA"
# Write-Host "SAPSID Instance Name and Instance Number for has_j : $SAPSID $instance_name$instance_number"

                    } elseif ($filename -match "^$($SAPSID)_(SCS)([0-9][0-9])_(.+)$") {
                        $has_scs = $true
                        $instance_name = $matches[1]
                        $instance_number = $matches[2]
                        $scsinstance_number = $instance_number
                        $SYSTEM_TYPE = "JAVA"
#   Write-Host "Instance Name and Instance Number for has_scs : $instance_name$instance_number"

                    } elseif ($filename -match "^$($SAPSID)_(W)([0-9][0-9])_(.+)$") {
                        $has_w = $true
                        $instance_name = $matches[1]
                        $instance_number = $matches[2]
                        $wdinstance_number=$instance_number
                        $SYSTEM_TYPE = "Unknown"
#   Write-Host "Instance Name and Instance Number for has_w : $instance_name$instance_number"
                    } elseif ($filename -match "^$($SAPSID)_(C)([0-9][0-9])_(.+)$") {
                        $has_c = $true
                        $instance_name = $matches[1]
                        $instance_number = $matches[2]
                        $csinstance_number=$instance_number
                        $SYSTEM_TYPE = "Unknown"
#   Write-Host "Instance Name and Instance Number for has_c : $instance_name$instance_number"
                    } elseif ($filename -match "^$($SAPSID)_(ERS)([0-9][0-9])_(.+)$") {
                        $has_ers = $true
                        $instance_name = $matches[1]
                        $instance_number = $matches[2]
                        $ersinstance_number = $instance_number
                    } 
                }


#-----------------------------------------------------------------------
Write-Output "${SAPSID}sapSid: ${SAPSID}" >> $outputFile
if ($ascsinstance_number) { Write-Output "${SAPSID}ascsInstanceNo: $ascsinstance_number" >> $outputFile }
if ($scsinstance_number) { Write-Output "${SAPSID}scsInstanceNo: $scsinstance_number" >> $outputFile }
if ($ersinstance_number) { Write-Output "${SAPSID}ersInstanceNo: $ersinstance_number" >> $outputFile }
# if ($dvebmgsinstance_number) { Write-Output "${SAPSID}appInstanceNo: $dvebmgsinstance_number" >> $outputFile }
# if ($applinstance_number) { Write-Output "${SAPSID}appInstanceNo: $applinstance_number" >> $outputFile }
# if ($j2eeinstance_number) { Write-Output "${SAPSID}j2eeInstanceNo: $j2eeinstance_number" >> $outputFile }
if ($wdinstance_number) { Write-Output "${SAPSID}wdInstanceNo: $wdinstance_number" >> $outputFile }
if ($csinstance_number) { Write-Output "${SAPSID}csInstanceNo: $csinstance_number" >> $outputFile }

# Initialize counter
$app_count = 1
$j2ee_count = 1

# If DVEBMGS instance is present
if ($has_dvebmgs -eq $true) {
    if ($dvebmgs_instance_number) {
        Write-Output "${SAPSID}appInstanceNo${app_count}: $dvebmgs_instance_number" >> $outputFile
        $app_count++
    }
}

# If D (dialog) instances are present
if ($has_d -eq $true) {
    if ($dxx_instances.Count -gt 0) {
        # Sort instance numbers numerically
        $sorted_dxx = $dxx_instances | Sort-Object { [int]$_ }

        foreach ($dinst in $sorted_dxx) {
$formatted = "{0:D2}" -f [int]$dinst
    Write-Output "${SAPSID}appInstanceNo${app_count}: $formatted" >> $outputFile
#            Write-Output "${SAPSID}appInstanceNo${app_count}: $dinst" >> $outputFile
            $app_count++
        }
    }
}

# If J (java) instances are present
if ($has_j -eq $true) {
    if ($jxx_instances.Count -gt 0) {
        # Sort instance numbers numerically
        $sorted_jxx = $jxx_instances | Sort-Object { [int]$_ }

        foreach ($jinst in $sorted_jxx) {
$formatted = "{0:D2}" -f [int]$jinst
    Write-Output "${SAPSID}j2eeInstanceNo${j2ee_count}: $formatted" >> $outputFile
            $j2ee_count++
        }
    }
}


#  # Standalone SCS 
   if ($has_scs -and -not $has_j) {
   $SystemName = "SCS Only"
    $SYSTEM_TYPE = "JAVA"
     } # Standalone SCS 

#------------------------------------------------------------------------
#  SCS and J instances reside on same host
#----------------------------------------------------------------------
if ($has_scs -and $has_j) {
collect-j2eeInfo
                }  #  SCS and J instances reside on same host

#  # Standalone ASCS 
if ( $has_ascs -and (-not $has_dvebmgs) -and (-not $has_d) ) {

   $SystemName = "ASCS Only"
    $SYSTEM_TYPE = "ABAP"
     } # Standalone ASCS 

#--------------------------------------------------------------------------------------------------------
#   D|DVEBMGS instance 
#----------------------------------------------------------------------------------------------------------
if ($has_ascs -and $has_dvebmgs) {
            
Collect-ABAPInfo 
                } #   DVEBMGS instance 

if ($has_ascs -and $has_d) {
            
Collect-ABAPInfo 
                } #   D instance 

if ($has_dvebmgs -and (-not $has_ascs)) {
            
Collect-ABAPInfo 
                } #   DVEBMGS instance 

if ($has_d -and (-not $has_ascs)) {
            
Collect-ABAPInfo 
                } #   D instance 

#-----------------------------------------------------
# Webdispatcher
#--------------------------------------------------------
if ($has_w) {
                    $SystemName = "SAP WebDispatcher"
                    $SYSTEM_TYPE = "WD"
                 $wdfilepath = "${exe_path}\webdispatchermanifest.mf"

# Retrieve the webdispatcher version
$wdVersionLine = Select-String -Path $wdfilepath -Pattern "webdispatcher release"
if ($wdVersionLine -match "webdispatcher release:\s*(.+)") {
    $wdversion = $matches[1]
}

# Retrieve the webdispatcher patch number
$wdPatchLine = Select-String -Path $wdfilepath -Pattern "webdispatcher patch number"
if ($wdPatchLine -match "webdispatcher patch number:\s*(.+)") {
    $wdpatch = $matches[1]
}   
    
  
$wdVersionsp="$wdversion $wdpatch"
$unicode_stat="-"

if ($wdVersionsp) { 
Write-Output "${SAPSID}wdVersion: $wdVersionsp" >> $outputFile
    }

# Write-Host "$SAPSID $SystemName $SYSTEM_TYPE $Versionsp"
 } # Webdispatcher

#----------------------------------------------------------
#  Content Server 
#-----------------------------------------------------
if ($instance_name -eq "C") {

        $manifestFile = "${exe_path}\contentservermanifest.mf"
        $csversion = (Select-String -Path $manifestFile -Pattern "contentserver release" | ForEach-Object { $_.Line.Split(':')[1].Trim() })
        $cspatch = (Select-String -Path $manifestFile -Pattern "contentserver patch number" | ForEach-Object { $_.Line.Split(':')[1].Trim() })

$SystemName="Content Server"
$SYSTEM_TYPE="CS"
$csVersionsp="$csversion $cspatch"
$unicode_stat="-"

if ($csVersionsp) { 
Write-Output "${SAPSID}csVersion: $csVersionsp" >> $outputFile
      }
# Collect-databaseInfo
} # Content Server


# Write-Host "$SAPSID  $SystemName  $SYSTEM_TYPE $($Metadata['OSName'])   $($Metadata['OSVersion'])   $($Metadata['CPUCores'])   $($Metadata['MemoryGB']) $($Metadata['dbvendorname']) $($Metadata['dbrelease'])  $Versionsp"


#
#### Print-Row
# Obtain the unicode informtion
#              if ($instance_name -in "D", "DVEBMGS", "ASCS", "ERS", "SCS", "J") {
if ($SYSTEM_TYPE -eq "JAVA" -or $SYSTEM_TYPE -eq "ABAP") {
            # Run disp+work -version command and capture the output
              $output = & "${exe_path}\disp+work.exe" "-version" 2>&1

            # Use Select-String to filter out the relevant lines like grep
              $kernel_version_line = $output | Select-String -Pattern 'kernel release'
              $kernel_patch_line = $output | Select-String -Pattern 'patch number'

           # Use -split or -replace to simulate cut
             $kernel_version = $kernel_version_line -replace 'kernel release\s+', ''
             $kernel_patch = $kernel_patch_line -replace 'patch number\s+', ''
            $unicode = $output | Select-String -Pattern 'compilation mode' 
           $unicode_status = $unicode -replace 'compilation mode\s+', '' 
         if ( $unicode_status -eq "UNICODE" ) {
         $unicode_stat="Yes" }
          else {
          $unicode_stat="No"
         
        }
#         Write-Host "Unicode : $unicode_stat"
#             Write-Host "Kernel Version for ${instance_name}: $kernel_version"
#            Write-Host "Kernel Patch for ${instance_name} : $kernel_patch"
                                    } # Obtain the Unicode infomration
#---------------------------------------------------------------------


Write-Output "${SAPSID}systemType: $SYSTEM_TYPE" >> $outputFile
Write-Output "${SAPSID}systemName: $SystemName" >> $outputFile
Write-Output "${SAPSID}uniCode: $unicode_stat" >> $outputFile
Write-Output "${SAPSID}enviRonment: $environment" >> $outputFile
if ($applVersionsp) { 
Write-Output "${SAPSID}applVersion: $applVersionsp" >> $outputFile
}
if ($SystemName) { 
Write-Output "${SAPSID}systemName: $SystemName" >> $outputFile
}

Collect-databaseInfo


# Write-Host "$SAPSID $SystemName $SYSTEM_TYPE $environment $unicode_stat $Versionsp $($Metadata.vmName) $($Metadata.CPUCores) $($Metadata.MemoryGB)GB $($Metadata.DiskTotalGB)GB $($Metadata.platform) $($Metadata.OSName) $($Metadata.OSVersion)  $($Metadata.dbvendorname)  $($Metadata.dbrelease)  $($Metadata.region)  $($Metadata.subscriptionId)"
            } #4 Obtain Valid SID

        } # 3

    } # 2
  }  # 1. List the windows drives

# } # end of function collect-applinfo

# If no valid SAP SID found at all
if (-not $foundValidSID) {
    # Prepare a default/fallback row indicating "No SAP application found"
#### Print-Row
}
#---------------------------------------------------------------------------------



#------------------------------------------------------------
# Convert flat file to structured JSON with SID grouping 
#------------------------------------------------------------

$input_file = "C:\tmp\config_details.txt"
$output_file = "C:\tmp\config_details.json"

# Use ordered hashtable to preserve order
$main_fields = [ordered]@{}
$sid_fields = @{}
$sid_order = @{}

Get-Content $input_file | ForEach-Object {
    $line = $_.Trim()
    if ($line -eq "") { return }

    $parts = $line -split ":", 2
    if ($parts.Count -lt 2) { return }

    $key = $parts[0].Trim()
    $value = $parts[1].Trim()

    if ($key -cmatch '^([A-Z]{3})([a-zA-Z0-9]+)$') {
        $sid = $matches[1]
        $subkey = $matches[2]

        if ($subkey -eq "Sid") { $subkey = "sapSid" }

        if (-not $sid_fields.ContainsKey($sid)) { $sid_fields[$sid] = @{} }
        $sid_fields[$sid][$subkey] = $value

        if (-not $sid_order.ContainsKey($sid)) {
            $sid_order[$sid] = @($subkey)
        }
        elseif (-not $sid_order[$sid].Contains($subkey)) {
            $sid_order[$sid] += $subkey
        }
    }
    else {
        $main_fields[$key] = $value
    }
}

$jsonObject = [ordered]@{}

foreach ($key in $main_fields.Keys) {
    $jsonObject[$key] = $main_fields[$key]
}

if ($sid_fields.Count -gt 0) {
    $sapSystems = @()
    foreach ($sid in $sid_fields.Keys) {
        $sapEntry = [ordered]@{}

        if ($sid_fields[$sid].ContainsKey("sapSid")) {
            $sapEntry["sapSid"] = $sid_fields[$sid]["sapSid"]
        }
        else {
            $sapEntry["sapSid"] = $sid
        }

        foreach ($subkey in $sid_order[$sid]) {
            if ($subkey -ne "sapSid") {
                $sapEntry[$subkey] = $sid_fields[$sid][$subkey]
            }
        }

        $sapSystems += $sapEntry
    }
    $jsonObject["sapSystems"] = $sapSystems
}

$jsonObject | ConvertTo-Json -Depth 10 -Compress:$false | Out-File -FilePath $output_file -Encoding utf8

Get-Content $output_file



Write-Host ""
Write-Host "------------------------------------------------------------------------"
Write-Host "JSON file generated at: $output_file"
Write-Host "------------------------------------------------------------------------"
