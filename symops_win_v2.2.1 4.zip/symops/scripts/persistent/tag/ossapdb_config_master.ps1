# Output file path
$outputFile = "C:\tmp\config_details_ossapdb.log"

# Create output directory if it doesn't exist
if (!(Test-Path "C:\tmp")) {
    New-Item -Path "C:\tmp" -ItemType Directory 2>&1
}

# Remove the file if it exists to ensure it is overwritten
if (Test-Path $outputFile) {
    Remove-Item $outputFile -Force
}

#---------------------------------------------------------------------
# OS Details 
#----------------------------------------------------------------------

# Get cloud platform based on asset tag or UUID
$assetTag = Get-WmiObject -Class Win32_SystemEnclosure | Select-Object -ExpandProperty SMBIOSAssetTag
$uuid = (Get-WmiObject -Class Win32_ComputerSystemProduct).UUID

if ($assetTag -eq '7783-7084-3265-9085-8269-3286-77') {
    Write-Output "cloudPlatform: Azure" >> $outputFile
} elseif ($uuid -like 'ec2*') {
    Write-Output "cloudPlatform: AWS" >> $outputFile
} else {
    Write-Output "cloudPlatform: Others" >> $outputFile
}

# Get OS details
$os = Get-WmiObject -Class Win32_OperatingSystem
Write-Output "vmosPlatform: $($os.Caption)" >> $outputFile
Write-Output "vmosArchitecture: $($os.OSArchitecture)" >> $outputFile
Write-Output "vmosVersion: $($os.Version)" >> $outputFile
Write-Output "vmHostname: $($env:COMPUTERNAME)" >> $outputFile

# Get CPU and Memory details
$cpuCores = (Get-WmiObject -Class Win32_Processor | Measure-Object -Property NumberOfCores -Sum).Sum
$memory = [math]::Round((Get-WmiObject -Class Win32_ComputerSystem).TotalPhysicalMemory / 1GB, 2)

# Get Swap space (Page File Usage)
$swapUsage = Get-WmiObject -Class Win32_PageFileUsage
$swapTotal = ($swapUsage | Measure-Object -Property AllocatedBaseSize -Sum).Sum
$swap = if ($swapTotal -ne $null) { [math]::Round($swapTotal / 1024, 2) } else { 0 }

Write-Output "vmCpu:  $cpuCores" >> $outputFile
Write-Output "vmMemory: ${memory}GB" >> $outputFile
Write-Output "vmSwap: ${swap}GB" >> $outputFile

# Get IP details
$ipAddresses = (Get-NetIPAddress -AddressFamily IPv4 | Where-Object { $_.IPAddress -ne "127.0.0.1" }).IPAddress
$numIPs = $ipAddresses.Count
if ($numIPs -gt 1) {
    $primaryIP = $ipAddresses[0]
    $secondaryIPs = $ipAddresses[1..($ipAddresses.Count - 1)] -join ", "
    Write-Output "secondaryIpAssigned: Yes" >> $outputFile
    Write-Output "primaryIp: $primaryIP" >> $outputFile
    Write-Output "secondaryIp: $secondaryIPs" >> $outputFile
} else {
    Write-Output "secondaryIpAssigned: No" >> $outputFile
    Write-Output "primaryIp: $ipAddresses" >> $outputFile
}

# Fetch the local timezone information
$timeZoneInfo = [System.TimeZoneInfo]::Local

# Fetch the timezone display name
$timeZoneDisplayName = $timeZoneInfo.DisplayName

# Construct the desired output (we only need the DisplayName)
$formattedTimeZone = $timeZoneDisplayName

# Output the time zone information to a file
Write-Output "TimeZone: $formattedTimeZone" >> $outputFile



# Get SAP Hostagent version and patch information
$hostAgentPath = "C:\Program Files\SAP\hostctrl\exe\saphostctrl.exe"

if (Test-Path $hostAgentPath) {
    $sapHostAgentVersion = & "$hostAgentPath" -function ExecuteOperation -name versioninfo | Select-String -Pattern "kernel release" | ForEach-Object { $_.Line.Split()[-1] }
    $sapHostAgentPatch = & "$hostAgentPath" -function ExecuteOperation -name versioninfo | Select-String -Pattern "patch number" | ForEach-Object { $_.Line.Split()[-1] }
    Write-Output "sapHostagentVersion: $sapHostAgentVersion" >> $outputFile
    Write-Output "sapHostagentPatch: $sapHostAgentPatch" >> $outputFile
}

#==============================================================================

# Get the current hostname
$hostname = $env:COMPUTERNAME

# Define the list of physical drives to check (e.g., C:, D:, E:, etc.)
$physical_drives = Get-PSDrive -PSProvider FileSystem | Where-Object { $_.Name -match '[C-Z]' }

# 1: Outer Loop - Loop through each physical drive
foreach ($drive in $physical_drives) {
    # Define the base path for each drive
    $physical_base_path = "$($drive.Root)usr\sap"

    # 2: Check if the SAP base path exists on the current drive
    if (Test-Path $physical_base_path) {
        # Get all possible SIDs from the physical drive path
        $sids = Get-ChildItem -Path $physical_base_path | Where-Object { $_.PSIsContainer } | Select-Object -ExpandProperty Name

        # 3: Inner Loop - Loop through each SID found on the current drive
        foreach ($sid in $sids) {
            # Define the profile and exe paths
            $physical_profile_path = Join-Path -Path "$physical_base_path\$sid" -ChildPath "SYS\profile"
            $physical_exe_path = "$($drive.Root)usr\sap\$sid\SYS\exe\uc\NTAMD64"

            # Check if the exe path exists for the current SID
            if (Test-Path $physical_exe_path) {
                

                # Execute a command or perform an action using the $physical_exe_path for each SID
                # Example: Run a command or check files in the exe path
                $exepath = $physical_exe_path
#      Write-Host "exepath: $exepath "         
            }

            # 4: Check if the SYS\profile folder exists on the physical drive for the current SID
            if (Test-Path $physical_profile_path) {
               

                # Get all files from the profile path
                $profile_files = Get-ChildItem -Path $physical_profile_path

                # Filter out unwanted files, including backup filenames like azaprwinsapdb.*
                $filtered_files = $profile_files | Where-Object {
                    ($_ -notmatch "DEFAULT\.[0-9]+\.PFL") -and 
                    ($_.Name -eq "DEFAULT.PFL" -or $_.Name -match "^$($sid)_([A-Z]+)([0-9]+)_(.+)$") -and
                    ($_.Name -notmatch "\..+$")  # Exclude files with an extension (e.g., .1, .bak)
                }

                # 5: If there are valid filtered profile files, proceed
                if ($filtered_files.Count -ne 0) {
                   

                    # 6: Inner-most Loop - Loop through filtered files
                    $filtered_files | ForEach-Object {
                      

                        # Use regex to extract instance name, instance number, and hostname from the filename
                        if ($_.Name -match "^$($sid)_([A-Z]+)([0-9]+)_(.+)$") {
                            $instance_name = $matches[1]
                            $instance_number = $matches[2]
                            $instance_hostname = $matches[3]

                            # Output the extracted instance details
#                            Write-Host "SID: $sid, Instance Name: $instance_name, Instance Number: $instance_number, Hostname: $instance_hostname"
                        }
# 9 Check if the instance name matches the conditions 
              if ($instance_name -in "D", "DVEBMGS", "ASCS", "ERS", "SCS", "J") {
# Obtain the kernel version and patch
            # Run disp+work -version command and capture the output
              $output = & "${exepath}\disp+work.exe" "-version" 2>&1

            # Use Select-String to filter out the relevant lines like grep
              $kernel_version_line = $output | Select-String -Pattern 'kernel release'
              $kernel_patch_line = $output | Select-String -Pattern 'patch number'

           # Use -split or -replace to simulate cut
             $kernel_version = $kernel_version_line -replace 'kernel release\s+', ''
             $kernel_patch = $kernel_patch_line -replace 'patch number\s+', ''

#             Write-Host "Kernel Version for ${instance_name}: $kernel_version"
#            Write-Host "Kernel Patch for ${instance_name} : $kernel_patch"
                                    } # 9 Instance name matches

           # Define SAP user in lowercase
              $sapsid = $SID.ToLower()
             $sapuser = "${sapsid}adm"
             $SAP_USER = $sapuser
#           Write-Host "${sapsid} , ${sapuser}, ${sid}, ${SAPSID}, ${SID}"

#-----------------------------------------------------------------#-------------------------------
#
# SMDA  Instance 
#
#-----------------------------------------------------------------#------------------------------
# Check if SAPSID is DAA

 if ($SID -eq "DAA") {

	Write-Output "daaSid: $SID" >> $outputFile
	Write-Output "daaInstanceName: $instance_name" >> $outputFile
	Write-Output "daaInstanceNumber: $instance_number" >> $outputFile
	Write-Output "daaInstanceHostname: $instance_hostname" >> $outputFile
	Write-Output "daaUser: daaadm" >> $outputFile
 # Define the path to the installationinfo.properties file
$filepath = "${physical_base_path}\$SID\SMDA${instance_number}\SMDAgent\configuration\installationinfo.properties"


# Read the file line by line
$fileContent = Get-Content -Path $filePath

# Search for the line containing KERNEL_VERSION
$kernelVersionLine = $fileContent | Where-Object { $_ -match "^KERNEL_VERSION=" }

# Extract the Kernel version and patch number
if ($kernelVersionLine -match "KERNEL_VERSION=([0-9]+)\.([0-9]+)\.") {
    $kernelVersion = $matches[1]  # Extracts the version (e.g., 753)
    $kernelpatch = $matches[2]    # Extracts the patch number (e.g., 1400)
 

	Write-Output "daaKernelVersion: $kernelVersion" >> $outputFile
	Write-Output "daaKernelPatch: $kernelPatch" >> $outputFile
            }
# Extract the Diagnostic version, SPS level and Patch number 
# Define the path to the diagnosticagent.mf file
$dfilePath = "${physical_base_path}\$SID\SMDA${instance_number}\diagnosticsagent.mf"

# Read the file and search for the specific fields using Select-String
$releaseLine = Select-String -Path $dfilePath -Pattern "^release:\s*([0-9]+\.[0-9]+)"
$servicePackLine = Select-String -Path $dfilePath -Pattern "^servicepack:\s*([0-9]+)"
$patchNumberLine = Select-String -Path $dfilePath -Pattern "^patchnumber:\s*([0-9]+)"

# Extract the values using regex matching
if ($releaseLine -match "release:\s*([0-9]+\.[0-9]+)") {
    $release = $matches[1] -replace '\.', ''  # Remove the dot to convert 7.20 to 720
}

if ($servicePackLine -match "servicepack:\s*([0-9]+)") {
    $servicePack = $matches[1]
}

if ($patchNumberLine -match "patchnumber:\s*([0-9]+)") {
    $patchNumber = $matches[1]
}

# Output the extracted values
if ($release -and $servicePack -and $patchNumber) {
    Write-Output "daaRelease: $release" >> $outputFile
    Write-Output "daaServicePack: $servicePack" >> $outputFile
    Write-Output "daaPatchNumber: $patchNumber" >> $outputFile
}
			}  # DAA           
#-----------------------------------------------------------------#-------------------------------
#
# ASCS Instance 
#
#-----------------------------------------------------------------#------------------------------
if ($instance_name -eq "ASCS") {
    Write-Output "ascsSid: $SID"  >> $outputFile
    Write-Output "ascsInstanceName: $instance_name"  >> $outputFile
    Write-Output "ascsInstanceNumber: $instance_number" >> $outputFile 
    Write-Output "ascsInstanceHostname: $instance_hostname"  >> $outputFile
    Write-Output "ascsSapUser: $SAP_USER"  >> $outputFile
#    Write-Output "ascsSapSystemType: ASCS"  >> $outputFile
    Write-Output "ascsKernelVersion: $kernel_version" >> $outputFile 
    Write-Output "ascsKernelPatch: $kernel_patch"  >> $outputFile

    $ha_config = & "${exepath}\sapcontrol.exe" -nr $instance_number -prot PIPE -function HAGetFailoverConfig 2>&1
    $ha_enabled = $ha_config | Select-String -Pattern "HAActive:" | ForEach-Object { $_.ToString().Split(':')[1].Trim() }

    if ($ha_enabled -eq "TRUE") {
        Write-Output "ascsHaEnabled: $ha_enabled"  >> $outputFile
        $ha_active_nodes = $ha_config | Select-String -Pattern "HAActiveNode:" | ForEach-Object { $_.ToString().Split(':')[1].Trim() }
        $ha_nodes = $ha_config | Select-String -Pattern "HANodes" | ForEach-Object { $_.ToString().Split(':')[1].Trim() }

        Write-Output "ascsHaActiveNodes: $ha_active_nodes"  >> $outputFile
        Write-Output "ascsHaNodes: $ha_nodes"  >> $outputFile
                              }
                         }   # ASCS

#-----------------------------------------------------------------#-------------------------------
#
# ERS Instance 
#
#-----------------------------------------------------------------#------------------------------

if ($instance_name -eq "ERS") {
    Write-Output "ersSid: $SID"  >> $outputFile
    Write-Output "ersInstanceName: $instance_name"  >> $outputFile
    Write-Output "ersInstanceNumber: $instance_number"  >> $outputFile
    Write-Output "ersInstanceHostname: $instance_hostname"  >> $outputFile
    Write-Output "ersSapUser: $sapuser"  >> $outputFile
    Write-Output "ersKernelVersion: $kernel_version"  >> $outputFile
    Write-Output "ersKernelPatch: $kernel_patch" >> $outputFile 

    $ha_config = & "${exepath}\sapcontrol.exe" -nr $instance_number -prot PIPE -function HAGetFailoverConfig 2>&1
    $ha_enabled = $ha_config | Select-String -Pattern "HAActive:" | ForEach-Object { $_.ToString().Split(':')[1].Trim() }

    if ($ha_enabled -eq "TRUE") {
        Write-Output "ascsHaEnabled: $ha_enabled"  >> $outputFile
        $ha_active_nodes = $ha_config | Select-String -Pattern "HAActiveNode:" | ForEach-Object { $_.ToString().Split(':')[1].Trim() }
        $ha_nodes = $ha_config | Select-String -Pattern "HANodes" | ForEach-Object { $_.ToString().Split(':')[1].Trim() }

        Write-Output "ascsHaActiveNodes: $ha_active_nodes" >> $outputFile 
        Write-Output "ascsHaNodes: $ha_nodes"  >> $outputFile
                              }
                         }   # ERS

#-----------------------------------------------------------------#-------------------------------
#
# SCS Instance 
#
#-----------------------------------------------------------------#------------------------------
if ($instance_name -eq "SCS") {
    Write-Output "scsSid: $SID"  >> $outputFile
    Write-Output "scsInstanceName: $instance_name"  >> $outputFile
    Write-Output "scsInstanceNumber: $instance_number" >> $outputFile
    Write-Output "scsInstanceHostname: $instance_hostname"  >> $outputFile
    Write-Output "scsSapUser: $SAP_USER"  >> $outputFile
#    Write-Output "scsSapSystemType: ASCS"  
    Write-Output "scsKernelVersion: $kernel_version"  >> $outputFile
    Write-Output "scsKernelPatch: $kernel_patch"  >> $outputFile

    $ha_config = & "${exepath}\sapcontrol.exe" -nr $instance_number -prot PIPE -function HAGetFailoverConfig 2>&1
    $ha_enabled = $ha_config | Select-String -Pattern "HAActive:" | ForEach-Object { $_.ToString().Split(':')[1].Trim() }

    if ($ha_enabled -eq "TRUE") {
        Write-Output "scsHaEnabled: $ha_enabled"  >> $outputFile
        $ha_active_nodes = $ha_config | Select-String -Pattern "HAActiveNode:" | ForEach-Object { $_.ToString().Split(':')[1].Trim() }
        $ha_nodes = $ha_config | Select-String -Pattern "HANodes" | ForEach-Object { $_.ToString().Split(':')[1].Trim() }

        Write-Output "scsHaActiveNodes: $ha_active_nodes"  >> $outputFile
        Write-Output "scsHaNodes: $ha_nodes"   >> $outputFile
                              }
                         }   # SCS

#---------------------------------------------------
#  Content Server 
#-----------------------------------------------------
if ($instance_name -eq "C") {
Write-Output "cpasSid: $SID" >> $outputFile
Write-Output "cpasInstanceName: $instance_name"  >> $outputFile
Write-Output "cpasInstanceNumber: $instance_number"  >> $outputFile
Write-Output "cpasInstanceHostname: $instance_hostname" >> $outputFile 
Write-Output "cpasSapUser: $SAP_USER" >> $outputFile
Write-Output "cpasSapSystemType: Content Server" >> $outputFile

# Retrieve Kernel Version and Patch level using sapcontrol

    $kernelInfo = & "${exepath}\sapcontrol.exe" -nr $instance_number -prot PIPE -function GetVersionInfo
    $kernelVersion = ($kernelInfo | Select-String -Pattern "sapstartsrv" | ForEach-Object { $_.Line.Split(',')[1].Trim() })
    $kernelPatch = ($kernelInfo | Select-String -Pattern "sapstartsrv" | ForEach-Object { $_.Line.Split(',')[2].Split(' ')[2].Trim() })

Write-Output "cpasKernelVersion: $kernelVersion" >> $outputFile
Write-Output "cpasKernelPatch: $kernelPatch" >> $outputFile

$manifestFile = "${exepath}\contentservermanifest.mf"
$contentServerVersion = (Select-String -Path $manifestFile -Pattern "contentserver release" | ForEach-Object { $_.Line.Split(':')[1].Trim() })
        $contentServerPatch = (Select-String -Path $manifestFile -Pattern "contentserver patch number" | ForEach-Object { $_.Line.Split(':')[1].Trim() })

Write-Output "contentServerVersion: $contentServerVersion" >> $outputFile
Write-Output "contentServerPatch: $contentServerPatch" >> $outputFile
} #Content Server

#=========================================================== 
# WebDispatcher
#-----------------------------------------------------------
        # Retrieve Web Dispatcher version and patch level for 'W' instance
        if ($instance_name -eq "W") {

        Write-Output "wpasSid: $SID" >> $outputFile
        Write-Output "wpasInstanceName: $instance_name" >> $outputFile 
        Write-Output "wpasInstanceNumber: $instance_number" >> $outputFile 
        Write-Output "wpasInstanceHostname: $instance_hostname" >> $outputFile
        Write-Output "wpasSapUser: $SAP_USER" >> $outputFile
        Write-Output "wpasSapSystemType: Webdispatcher" >> $outputFile
        
# Retrieve Kernel Version and Patch level using sapcontrol
    $kernelInfo = & "${exepath}\sapcontrol.exe" -nr $instance_number -prot PIPE -function GetVersionInfo

    $kernelVersion = ($kernelInfo | Select-String -Pattern "sapstartsrv" | ForEach-Object { $_.Line.Split(',')[1].Trim() })

    $kernelPatch = ($kernelInfo | Select-String -Pattern "sapstartsrv" | ForEach-Object { $_.Line.Split(',')[2].Split(' ')[2].Trim() })

echo "wpasKernelVersion: $kernelVersion" >> $outputFile
echo "wpasKernelPatch: $kernelPatch" >> $outputFile


$filepath = "${exepath}\webdispatchermanifest.mf"

# Retrieve the webdispatcher version
$webDispatcherVersionLine = Select-String -Path $filepath -Pattern "webdispatcher release"
if ($webDispatcherVersionLine -match "webdispatcher release:\s*(.+)") {
    $webdispatcher_version = $matches[1]
}

# Retrieve the webdispatcher patch number
$webDispatcherPatchLine = Select-String -Path $filepath -Pattern "webdispatcher patch number"
if ($webDispatcherPatchLine -match "webdispatcher patch number:\s*(.+)") {
    $webdispatcher_patch = $matches[1]
}       
     
Write-Output  "webDispatcherVersion: $webdispatcher_version" >> $outputFile
Write-Output  "webDispatcherPatch: $webdispatcher_patch" >> $outputFile
        } # Webdispatcher

#====================================================================

#---------------------------------------------------------
# System Type 
#---------------------------------------------------
# 10 System type for Instance name D or DVEBMGS or J
if ($instance_name -in "D", "DVEBMGS", "J") {

        $profileFile= "$physical_base_path\$SID\SYS\profile\DEFAULT.PFL"
         # Check if the DEFAULT.PFL profile file exists
             if (Test-Path $profileFile) {
        # Read the system type from the profile file
            $systemType = Select-String -Path $profileFile -Pattern '^system/type' | ForEach-Object {
             $_.Line -split '=' | Select-Object -Last 1
               }
                # Trim any leading/trailing spaces
                 $systemType = $systemType.Trim()

               # Check if the system type is empty
               if (-not $systemType) {
               $systemType = "Unknown"
                       }
					   
# Set SECUDIR environment variable
# $env:SECUDIR = "E:\usr\sap\NWD\SYS\global\security"
					   
 
try {
    # Execute the sapgenpse command and capture the output
    $version_line_info = & "${exepath}\sapgenpse.exe" support_info | ForEach-Object { $_.Trim() } | Where-Object { $_ -ne "" } | Select-String -Pattern "Version:" | ForEach-Object { $_.Line.Trim() }


    # Check if version info was captured
    if ($version_line_info) {
        Write-Host "Version Information: $version_line_info"
    } else {
        Write-Host "No version information found."
    }
} catch {
    Write-Error "An error occurred while executing the sapgenpse command: $_"
}


      $version_line = $version_line_info.Trim()
      $cleaned_version_line = $version_line -replace '\s+', ' '
      $split_info = $cleaned_version_line -split ': '

   $cryptolib_version = $split_info[1].Trim()
        # Output the Cryptolib version
        Write-Output "pasCryptolibVersion: $cryptolib_version" >> $outputFile 
           


# for ABAP stack only
        if ($instance_name -in "D", "DVEBMGS") {
 #            Write-Output "System Type for Instance Name $instance_name : $systemType"
                Write-Output "pasSid: $SID"  >> $outputFile
    		Write-Output "pasInstanceName: $instance_name"  >> $outputFile
    		Write-Output "pasInstanceNumber: $instance_number" >> $outputFile 
    		Write-Output "pasInstanceHostname: $instance_hostname"  >> $outputFile
    		Write-Output "pasSapUser: $SAP_USER"  >> $outputFile
  		Write-Output "pasSapSystemType: $systemType"  >> $outputFile
    		Write-Output "pasKernelVersion: $kernel_version"  >> $outputFile
    		Write-Output "pasKernelPatch: $kernel_patch" >> $outputFile 
                Write-Output "pasCryptolibVersion: $cryptolib_version" >> $outputFile 

		# Execute sapcontrol command to get the component list
		$output = & "${exepath}\sapcontrol.exe" -nr $instance_number -prot PIPE -function ABAPGetComponentList

		# Extract NetWeaver information for SAP_BASIS
		$netweaver_info = $output | Select-String -Pattern "SAP_BASIS"

		if ($netweaver_info) {
   # Split the line by commas and store the results in an array
 		   $split_info = $netweaver_info -split ','

    # The second element in the array is the NetWeaver version (750)
		    $NWversion = $split_info[1].Trim()

    # The third element in the array is the SPS level (0)
   		 $sps_level = $split_info[2].Trim()

    # Output the results
   	 Write-Output "pasNetweaverVersion: $NWversion"  >> $outputFile
  	  Write-Output "pasNetweaverSpLevel: $sps_level"  >> $outputFile
		}   #netweaver_info

# Check if there is information about SAP_APPL
	$appl_info = $output | Select-String -Pattern "SAP_APPL"

		if ($appl_info) {
    # Split the line by commas and store the results in an array
	    $split_appl_info = $appl_info -split ','

    # The second element is the application version, and the third is the SPS level
 	   $applversion = $split_appl_info[1].Trim()
 	   $sps_level = $split_appl_info[2].Trim()

    # Output the application version and SPS level
    Write-Output "pasApplicationVersion: $applversion"  >> $outputFile
    Write-Output "pasApplicationSPSLevel: $sps_level"  >> $outputFile
                 }  #appl_info
#----------------------------------------------------------
# solution manager Version and SPS 
# Check if there is information about ST Component of Solution Manager
	$sm_info = $output | Select-String -Pattern "ST,"

		if ($sm_info) {
    # Split the line by commas and store the results in an array
	    $split_sm_info = $sm_info -split ','

    # The second element is the application version, and the third is the SPS level
 	   $smversion = $split_sm_info[1].Trim()
 	   $sm_sps_level = $split_sm_info[2].Trim()

    # Output the application version and SPS level
    Write-Output "smProductVersion: $smversion"  >> $outputFile
    Write-Output "smProductSPSLevel: $sm_sps_level"  >> $outputFile
                 }  #solution Manager info


#-----------------------------------------------
              }  # ABAP stack only 

# Netwevare version for Java Stack
       if ($instance_name -eq "J") {

$instance = "$instance_name$instance_number"
#            Write-Output "System Type for Instance Name $instance_name : $systemType"
                Write-Output "jpasSid: $SID"  >> $outputFile
    		Write-Output "jpasInstanceName: $instance_name"  >> $outputFile
    		Write-Output "jpasInstanceNumber: $instance_number" >> $outputFile 
    		Write-Output "jpasInstanceHostname: $instance_hostname"  >> $outputFile
    		Write-Output "jpasSapUser: $SAP_USER"  >> $outputFile
  		Write-Output "jpasSapSystemType: $systemType"  >> $outputFile
    		Write-Output "jpasKernelVersion: $kernel_version"  >> $outputFile
    		Write-Output "jpasKernelPatch: $kernel_patch" >> $outputFile 
                Write-Output "jpasCryptolibVersion: $cryptolib_version" >> $outputFile 

# Get all drives on the system (only filesystem drives)
$drives = Get-PSDrive -PSProvider FileSystem | Select-Object -ExpandProperty Root

# Initialize variables for results
$netweaverVersion = ""
$netweaverSP = ""

# Loop through each available drive to find the file
foreach ($drive in $drives) {
    $filePath = "$drive\usr\sap\$SAPSID\$instance\work\std_server0.out"
    
    if (Test-Path $filePath) {
        # Retrieve NetWeaver version
        $netweaverVersion = Select-String -Path $filePath -Pattern 'AS Java version \[([0-9]+)\.([0-9]+)' |
            ForEach-Object { $_.Matches.Groups[1].Value + "." + $_.Matches.Groups[2].Value }
        
        # Remove the dot from the version (e.g., 7.50 -> 750)
        $netweaverVersion = $netweaverVersion -replace '\.', ''

        # Retrieve NetWeaver SP level
        $netweaverSP = Select-String -Path $filePath -Pattern 'SP ([0-9]+)' |
            ForEach-Object { $_.Matches.Groups[1].Value }

        break # Exit loop once the file is found
           }
       }

# Output results to file if version and SP level are found
if ($netweaverVersion -and $netweaverSP) {
     Write-Output "jpasNetweaverVersion: $netweaverVersion" >> $outputFile
    Write-Output "jpasNetweaverSPLevel: $netweaverSP"  >> $outputFile
               }
             } # Java Stack
          }

       }   # 10 System t


#===============================================================
            

                    } # 6 End of inner-most loop ($filtered_files | ForEach-Object)
                } # 5 End of check for valid filtered files ($filtered_files.Count -ne 0)
            } # 4 End of check for SYS\profile path (Test-Path $physical_profile_path)
        } # 3 End of inner loop through SIDs (foreach $sid in $sids)
    }  # 2 End of check for SAP base path (Test-Path $physical_base_path)
}  # 1 End of outer loop through physical drives (foreach $drive in $physical_drives)

#================================================================================
#=============================================================
#
#-----------------------------------------------------------
# Database Details
#-------------------------------------------------------------

# Define the saphostctrl command to retrieve database systems
# Define the full path to the saphostctrl command
if (Test-Path $hostAgentPath) {
$output = & "$hostAgentPath" -function ListDatabaseSystems | Select-String -Pattern "^Database name:"

foreach ($line in $output) {
    # Extract the database SID
    $dbsid = ($line -split "Database name:")[1] -split "," | Select-Object -First 1
    $dbsid = $dbsid.Trim()

    # Extract the vendor
    $dbvendor = ($line -split "Vendor:")[1] -split "," | Select-Object -First 1
    $dbvendor = $dbvendor.Trim()

    # Extract the type
    $dbtype = ($line -split "Type:")[1] -split "," | Select-Object -First 1
    $dbtype = $dbtype.Trim()

    # Extract the release
    $dbrelease = ($line -split "Release:")[1] -split "," | Select-Object -First 1
    $dbrelease = $dbrelease.Trim()


# Assign the vendor name based on the value of $dbvendor
# if ($dbvendor -eq "ADA") {
#    $dbvendorname = "MAXDB"
# } 
# elseif ($dbvendor -eq "MSS") {
#     $dbvendorname = "MSSQL"
# } 
# elseif ($dbvendor -eq "SYB") {
#    $dbvendorname = "Sybase"
# } 
# elseif ($dbvendor -eq "ORA") {
#    $dbvendorname = "Oracle"
# } 

    # Assign the vendor name based on the value of $dbvendor
    switch ($dbvendor) {
        "ADA" { $dbvendorname = "MAXDB" }
        "MSS" { $dbvendorname = "MSSQL" }
        "SYB" { $dbvendorname = "Sybase" }
        "ORA" { $dbvendorname = "Oracle" }
        default { $dbvendorname = "Unknown" }
    }
# Check if all values were successfully extracted and display them
if ($dbsid -and $dbvendor -and $dbtype -and $dbrelease ) {
    Write-Output "dBSid: $dbsid" >> $outputFile
    Write-Output "dBVendor: $dbvendor" >> $outputFile
    Write-Output "dBVendorName: $dbvendorname" >> $outputFile
    Write-Output "dBType: $dbtype" >> $outputFile
    Write-Output "dBRelease: $dbrelease" >> $outputFile
    Write-Output "dBHostName: $hostname" >> $outputFile
Write-Output " " >> $outputFile
  } 
 }
}
(Get-Content $outputFile) | Where-Object { $_ -match '\S' } | Set-Content $outputFile
#---------------------------------------------------------------------
# Convert into JSON format 
#-------------------------------------------------------------------

# Input and output file paths
$inputFile = "C:\tmp\config_details.log"
$jsonOutputFile = "C:\tmp\config_details_$($env:COMPUTERNAME).json"

# Initialize an empty hashtable to store the key-value pairs
$jsonData = [ordered]@{}

# Read each line from the input file
Get-Content -Path $inputFile | ForEach-Object {
    $line = $_
    
    # Match lines in the "key: value" format
    if ($line -match '^([^:]+):\s*(.*)$') {
        # Extract key and value from the regex match
        $key = $matches[1].Trim()
        $value = $matches[2].Trim()
        
        # Format the key for JSON (replace spaces with underscores)
        $jsonKey = $key -replace ' ', '_'
        
        # Add the key-value pair to the hashtable
        $jsonData[$jsonKey] = $value
    }
}

# Convert the hashtable to JSON format
$jsonOutput = $jsonData | ConvertTo-Json -Depth 3

# Save the JSON output to the output file
$jsonOutput | Set-Content -Path $jsonOutputFile

Get-Content $jsonOutputFile

#Write-Host "JSON file generated at: $jsonOutputFile"